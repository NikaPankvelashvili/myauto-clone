import { useState } from "react";
import { ClickAwayListener } from "@mui/base";

export default function Model() {
  const [showDropDown, setShowDropDown] = useState<Boolean>(false);
  const [selectedModelIDs, setSelectedModelIDs] = useState<number[]>([]);

  return (
    <div className="mt-4">
      <label
        htmlFor="manInput"
        className="text-xs font-medium text-default mb-2"
      >
        მოდელი
      </label>
      <ClickAwayListener onClickAway={() => setShowDropDown((prev) => false)}>
        <div className="p-3 border-[1px] relative rounded-lg mt-2 flex content-between w-full text-xs">
          <div
            className="w-full flex cursor-pointer"
            onClick={() => setShowDropDown((prev) => !prev)}
          >
            <span className="w-full select-none overflow-hidden whitespace-nowrap text-ellipsis">
              {selectedManIDs.length === 0 ? (
                <input
                  id="manInput"
                  type="text"
                  className="focus:outline-none"
                  placeholder="ყველა მწარმოებელი"
                  value={manSearchTerm}
                  onChange={(e) => setManSearchTerm(e.target.value)}
                />
              ) : (
                <span>
                  {selectedManIDs.map((manID, index) => (
                    <span key={index}>{`${
                      fetchedManData![parseInt(manID) - 1].man_name
                    },`}</span>
                  ))}
                </span>
              )}
            </span>
            {selectedManIDs.length === 0 ? (
              showDropDown ? (
                <BsArrowUpShort size={"1.1rem"} />
              ) : (
                <BsArrowDownShort size={"1.1rem"} />
              )
            ) : (
              <div onClick={() => setSelectedManIDs([])}>
                <IoIosClose size={"1.1rem"} />
              </div>
            )}
          </div>
        </div>
      </ClickAwayListener>
    </div>
  );
}
