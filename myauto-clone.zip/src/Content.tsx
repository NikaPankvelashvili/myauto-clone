import React from "react";

export default function Content() {
  return <div className="h-96 w-96 bg-orange-600 "></div>;
}
